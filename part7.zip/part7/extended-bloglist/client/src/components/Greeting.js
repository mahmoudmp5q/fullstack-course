const Greeting = ({ name }) => (
  <p>
    Hello, <strong>{name}!</strong>
  </p>
);

export default Greeting;
